##
##Denise Tranberg
## Date Started: 7/10
## Date Completed: 7/13
## Chapter 10, Assignment 5A
##  Italian Flag program.
##################################################################################################
# P10.16
# A Group object is constructed with the top-left corner of it's bounding box.
# However, the true bounding box may be smaller if no shapes are added that touch the left or top edge.
# Reimplement the Group class so that the constructor takes
# an anchor point (which need not be top-left corner of bounding box).
# All added shapes are relative to this anchor point.
# Re-impliment the add method to update the top-left corner of the bounding box.
# Note that you no longer need to move a shape in the add method.
##################################################################################################




#  This program draws two Italian flags using the geometric shape classes. 
#

from ezgraphics import GraphicsWindow
from Assignment5A_shapes import Rectangle, Line, Group

# Define constants for the flag size.
FLAG_WIDTH = 150
FLAG_HEIGHT = FLAG_WIDTH * 2 // 3
PART_WIDTH = FLAG_WIDTH // 3
ANCHOR_X=50  #---This is the anchor point X axis to be called in group()
ANCHOR_Y=50  #---This is the anchor point Y axis to be called in group()


# Create the graphics window.
win = GraphicsWindow(500, 500)
canvas = win.canvas()

# Build the flag as a group shape.
flag = Group(ANCHOR_X,ANCHOR_Y) ##---Calling this with new anchor x & y axis)

part = Rectangle(0, 0, PART_WIDTH, FLAG_HEIGHT)
part.setColor("green")
flag.add(part)

part = Rectangle(PART_WIDTH * 2, 0, PART_WIDTH, FLAG_HEIGHT)
part.setColor("red")
flag.add(part)

flag.add(Line(PART_WIDTH, 0, PART_WIDTH * 2, 0))
flag.add(Line(PART_WIDTH, FLAG_HEIGHT, PART_WIDTH * 2, FLAG_HEIGHT))

# Draw the first flag in the upper-left area of the canvas.
flag.moveBy(10, 10)
flag.draw(canvas)

# Draw the second flag in the bottom-right area of the canvas.
flag.moveBy(130, 180)
flag.draw(canvas)

win.wait()
