##Denise Tranberg
## CIS 217_470
## Assignment 5B
## Date Started 7/10
## Date Completed 7/13
##
# P10.20
##################################################################################################
# Add a method scale(factor) to the GeometricShape class and implement it for each subclass.
# The method should scale the shape by a given factor.
# For example, a call shape.scale(0.5) makes the bounding box half as large,
# and moves the top-left corner halfway to the uper-left corner of the canvas.
###################################################################################################

#  This program draws two Italian flags using the geometric shape classes. 
#

from ezgraphics import GraphicsWindow
from Assignment5B_shapes import Rectangle, Line, Group

# Define constants for the flag size.
FLAG_WIDTH = 150
FACTOR = .5  # Factor to apply
FLAG_HEIGHT = (FLAG_WIDTH * 2 // 3)
PART_WIDTH = (FLAG_WIDTH // 3)







# Create the graphics window.
win = GraphicsWindow(600, 600)  # Increased default canvas
canvas = win.canvas()

# Build the flag as a group shape.

flag=Group()


#flag.scale(flag)

part = Rectangle(0, 0, PART_WIDTH, FLAG_HEIGHT,FACTOR)
part.scale(FACTOR)#--This scales only the rectangle
part.setColor("green")
flag.add(part)

newX=PART_WIDTH*FACTOR  # Changes the static X-axis
part = Rectangle(newX * 2, 0, PART_WIDTH, FLAG_HEIGHT,FACTOR)
part.scale(FACTOR)#--This scales only the rectangle
part.setColor("red")
flag.add(part)

tFlag=Line(PART_WIDTH, 0, PART_WIDTH * 2, 0,FACTOR)
tFlag.scale(FACTOR) #--This scales the top line
flag.add(tFlag)
bFlag=Line(PART_WIDTH, FLAG_HEIGHT, PART_WIDTH * 2, FLAG_HEIGHT,FACTOR)
bFlag.scale(FACTOR) #--This scales the bottom line
flag.add(bFlag)

# Draw the first flag in the upper-left area of the canvas.
flag.moveBy(10, 10)
flag.draw(canvas)

# Draw the second flag in the bottom-right area of the canvas.
flag.moveBy(130, 180)
flag.draw(canvas)

win.wait()
